package com.liquidglass.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.pm.ResolveInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)
    private val allApps = mutableListOf<AppEntry>()
    private lateinit var grid: GridLayout
    private lateinit var search: EditText
    private lateinit var countLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(20, 25, 43)
        window.navigationBarColor = Color.rgb(20, 25, 43)
        loadApps()
        buildScreen()
        showApps("")
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val list: List<ResolveInfo> = packageManager.queryIntentActivities(intent, 0)
        allApps.clear()
        list.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == packageName) return@mapNotNull null
            AppEntry(info.loadLabel(packageManager).toString(), pkg, info.loadIcon(packageManager))
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase(Locale.getDefault()) }
            .forEach { allApps.add(it) }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(14))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(25, 31, 53), Color.rgb(45, 48, 76), Color.rgb(20, 25, 43))
            )
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(8), dp(4), dp(16))
        }
        val time = TextView(this).apply {
            text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            textSize = 48f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        val date = TextView(this).apply {
            text = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("pt", "BR")).format(Date())
            textSize = 15f
            setTextColor(0xFFD5D9E8.toInt())
        }
        top.addView(time)
        top.addView(date)
        root.addView(top)

        val searchPanel = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(15), dp(2), dp(15), dp(2))
            background = rounded(0x44FFFFFF, 28f, 0x55FFFFFF)
        }
        val glass = TextView(this).apply {
            text = "⌕"
            textSize = 27f
            setTextColor(Color.WHITE)
            setPadding(0, 0, dp(8), 0)
        }
        search = EditText(this).apply {
            hint = "Pesquisar aplicativos"
            setHintTextColor(0xFFCFD3E0.toInt())
            setTextColor(Color.WHITE)
            textSize = 15f
            singleLine = true
            background = null
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setPadding(0, dp(10), 0, dp(10))
            addTextChangedListener(SimpleWatcher { showApps(it) })
        }
        searchPanel.addView(glass)
        searchPanel.addView(search, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(searchPanel)

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(20), dp(4), dp(10))
        }
        val title = TextView(this).apply {
            text = "Biblioteca"
            textSize = 19f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        countLabel = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFFCFD3E0.toInt())
            gravity = Gravity.END
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(countLabel)
        root.addView(header)

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
        }
        grid = GridLayout(this).apply {
            columnCount = 4
            useDefaultMargins = false
            setPadding(0, dp(4), 0, dp(12))
        }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(9), dp(8), dp(9))
            background = rounded(0x55FFFFFF, 30f, 0x66FFFFFF)
        }
        val dockApps = allApps.take(4)
        if (dockApps.isEmpty()) {
            val hint = TextView(this).apply {
                text = "Seus aplicativos aparecerão aqui"
                setTextColor(Color.WHITE)
                textSize = 13f
            }
            dock.addView(hint)
        } else {
            dockApps.forEach { app ->
                val item = appIcon(app, compact = true)
                dock.addView(item, LinearLayout.LayoutParams(0, dp(58), 1f))
            }
        }
        root.addView(dock)
        setContentView(root)
    }

    private fun showApps(query: String) {
        if (!::grid.isInitialized) return
        grid.removeAllViews()
        val filtered = allApps.filter { it.label.contains(query.trim(), true) }
        countLabel.text = "${filtered.size} aplicativos"
        filtered.forEach { app ->
            val item = appIcon(app, compact = false)
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(100)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(2), dp(3), dp(2), dp(7))
            }
            grid.addView(item, params)
        }
        if (filtered.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Nenhum aplicativo encontrado"
                setTextColor(0xFFE3E6F0.toInt())
                textSize = 14f
                gravity = Gravity.CENTER
            }
            grid.addView(empty, GridLayout.LayoutParams().apply { columnSpec = GridLayout.spec(0, 4) })
        }
    }

    private fun appIcon(app: AppEntry, compact: Boolean): View {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(3), dp(4), dp(3), dp(4))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(app.packageName)
                if (launch != null) startActivity(launch)
                else Toast.makeText(this@MainActivity, "Não foi possível abrir ${app.label}", Toast.LENGTH_SHORT).show()
            }
        }
        val iconHolder = FrameGlass(this).apply {
            gravity = Gravity.CENTER
            background = rounded(0x33FFFFFF, 19f, 0x55FFFFFF)
            addView(ImageView(this@MainActivity).apply {
                setImageDrawable(app.icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameGlass.LayoutParams(dp(42), dp(42), Gravity.CENTER))
        }
        item.addView(iconHolder, LinearLayout.LayoutParams(dp(58), dp(58)))
        if (!compact) {
            val label = TextView(this).apply {
                text = app.label
                textSize = 11f
                maxLines = 1
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setPadding(0, dp(5), 0, 0)
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            item.addView(label, LinearLayout.LayoutParams(-1, -2))
        }
        return item
    }

    private fun rounded(fill: Int, radius: Float, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(radius.toInt()).toFloat()
            setStroke(dp(1), stroke)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private class FrameGlass(context: android.content.Context) : android.widget.FrameLayout(context)

    private class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }
}
