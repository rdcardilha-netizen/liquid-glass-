# Liquid Glass Launcher Pro

Projeto independente da DOTS Launcher. Interface Android com estética Liquid Glass inspirada no iOS, mantendo compatibilidade com o pipeline GitHub Actions do projeto que compilou anteriormente.

## Stack de compilação
- Java 17
- Gradle 8.5
- Android Gradle Plugin 8.2.2
- Kotlin 1.9.22
- compileSdk 34
- minSdk 26

## Recursos
- Tela inicial com relógio e data
- Exibição do wallpaper atrás da interface (depende do suporte do dispositivo/launcher)
- Painéis translúcidos configuráveis de 0 a 100%
- Opção de blur em Android 12+ (RenderEffect)
- Temas de vidro: cristal, azul escuro, branco e preto
- Dock flutuante
- Pesquisa de aplicativos
- Grade de 3 a 6 colunas
- Tamanho dos ícones ajustável
- Rótulos, relógio, data, pesquisa e dock podem ser ativados/desativados
- Preferências salvas automaticamente

## Build
Extrair este ZIP diretamente para a pasta `proj/` e executar:
`gradle :app:assembleRelease --no-daemon`

## Limitações conhecidas
A transparência depende do wallpaper e da composição do Android. O blur é suportado nativamente em Android 12+ e pode variar por fabricante. Este projeto é uma base avançada, não uma cópia oficial do iOS nem inclui serviços privados da Apple.
