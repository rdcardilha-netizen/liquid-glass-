package com.liquidglass.launcher

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {
    private val ink = Color.WHITE
    private val muted = 0xFFD4D8E2.toInt()
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        window.statusBarColor = Color.rgb(22, 27, 43)
        window.navigationBarColor = Color.rgb(22, 27, 43)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(28))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(24, 30, 49), Color.rgb(48, 51, 76), Color.rgb(20, 24, 39))
            )
        }
        content.addView(TextView(this).apply {
            text = "LIQUID GLASS  /  PERSONALIZAÇÃO"
            textSize = 10f
            letterSpacing = .14f
            setTextColor(muted)
        })
        content.addView(TextView(this).apply {
            text = "Ajustes"
            textSize = 38f
            typeface = android.graphics.Typeface.create("sans-serif-light", 0)
            setTextColor(ink)
            setPadding(0, dp(4), 0, dp(16))
        })

        section("APARÊNCIA")
        addSeek("Transparência do vidro", Prefs.transparency(this), 100, "%") {
            Prefs.setTransparency(this, it)
        }
        addSwitch("Desfoque de fundo", "Efeito de blur quando suportado pelo Android 12+", Prefs.blur(this)) {
            Prefs.setBlur(this, it)
        }
        addChoice("Cor do vidro", listOf("Cristal", "Azul escuro", "Branco", "Preto"), Prefs.glassTint(this)) {
            Prefs.setGlassTint(this, it)
        }

        section("TELA INICIAL")
        addSwitch("Relógio grande", "Mostrar hora na tela inicial", Prefs.clock(this)) { Prefs.setClock(this, it) }
        addSwitch("Data", "Mostrar data abaixo do relógio", Prefs.date(this)) { Prefs.setDate(this, it) }
        addSwitch("Barra de pesquisa", "Mostrar pesquisa de aplicativos", Prefs.search(this)) { Prefs.setSearch(this, it) }
        addSwitch("Dock flutuante", "Mostrar os quatro primeiros aplicativos no dock", Prefs.dock(this)) { Prefs.setDock(this, it) }
        addSwitch("Nomes dos aplicativos", "Mostrar rótulos abaixo dos ícones", Prefs.labels(this)) { Prefs.setLabels(this, it) }

        section("ÍCONES E GRADE")
        addSeek("Tamanho dos ícones", Prefs.iconSize(this) - 40, 36, " dp") {
            Prefs.setIconSize(this, it + 40)
        }
        addChoice("Colunas da biblioteca", listOf("3", "4", "5", "6"), Prefs.columns(this) - 3) {
            Prefs.setColumns(this, it + 3)
        }

        content.addView(TextView(this).apply {
            text = "As alterações são salvas automaticamente. Volte à tela inicial para visualizar."
            textSize = 11f
            setTextColor(muted)
            setPadding(0, dp(22), 0, dp(12))
        })
        val scroll = ScrollView(this).apply { addView(content) }
        setContentView(scroll)
    }

    private fun section(name: String) {
        content.addView(TextView(this).apply {
            text = name
            textSize = 10f
            letterSpacing = .16f
            setTextColor(0xFFE3E7F0.toInt())
            setPadding(0, dp(20), 0, dp(5))
        })
    }

    private fun addSwitch(title: String, subtitle: String, checked: Boolean, changed: (Boolean) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(TextView(this).apply { text = title; textSize = 14f; setTextColor(ink) })
        labels.addView(TextView(this).apply { text = subtitle; textSize = 10f; setTextColor(muted); setPadding(0, dp(2), 0, 0) })
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Switch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, value -> changed(value) }
        })
        content.addView(row)
    }

    private fun addSeek(title: String, initial: Int, max: Int, suffix: String, changed: (Int) -> Unit) {
        val label = TextView(this).apply {
            text = "$title: $initial$suffix"
            textSize = 13f
            setTextColor(ink)
            setPadding(0, dp(7), 0, 0)
        }
        content.addView(label)
        content.addView(SeekBar(this).apply {
            this.max = max
            progress = initial.coerceIn(0, max)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    label.text = "$title: $value$suffix"
                    if (fromUser) changed(value)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })
    }

    private fun addChoice(title: String, options: List<String>, selected: Int, changed: (Int) -> Unit) {
        content.addView(TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(ink)
            setPadding(0, dp(8), 0, dp(7))
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        options.forEachIndexed { index, option ->
            val item = TextView(this).apply {
                text = option
                gravity = Gravity.CENTER
                textSize = 11f
                setTextColor(if (index == selected) Color.rgb(25, 29, 43) else ink)
                setBackgroundColor(if (index == selected) Color.WHITE else 0x334FFFFF)
                setPadding(dp(8), dp(10), dp(8), dp(10))
                setOnClickListener {
                    changed(index)
                    for (i in 0 until row.childCount) {
                        val v = row.getChildAt(i) as TextView
                        val active = i == index
                        v.setTextColor(if (active) Color.rgb(25, 29, 43) else ink)
                        v.setBackgroundColor(if (active) Color.WHITE else 0x334FFFFF)
                    }
                }
            }
            val lp = LinearLayout.LayoutParams(0, -2, 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            row.addView(item, lp)
        }
        content.addView(row)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
