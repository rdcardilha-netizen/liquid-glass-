package com.liquidglass.launcher

import android.content.Context

object Prefs {
    private const val FILE = "liquid_glass_preferences"
    private fun p(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun transparency(c: Context) = p(c).getInt("transparency", 38)
    fun setTransparency(c: Context, v: Int) = p(c).edit().putInt("transparency", v.coerceIn(0, 100)).apply()

    fun blur(c: Context) = p(c).getBoolean("blur", true)
    fun setBlur(c: Context, v: Boolean) = p(c).edit().putBoolean("blur", v).apply()

    fun columns(c: Context) = p(c).getInt("columns", 4)
    fun setColumns(c: Context, v: Int) = p(c).edit().putInt("columns", v.coerceIn(3, 6)).apply()

    fun iconSize(c: Context) = p(c).getInt("icon_size", 54)
    fun setIconSize(c: Context, v: Int) = p(c).edit().putInt("icon_size", v.coerceIn(40, 76)).apply()

    fun labels(c: Context) = p(c).getBoolean("labels", true)
    fun setLabels(c: Context, v: Boolean) = p(c).edit().putBoolean("labels", v).apply()

    fun clock(c: Context) = p(c).getBoolean("clock", true)
    fun setClock(c: Context, v: Boolean) = p(c).edit().putBoolean("clock", v).apply()

    fun date(c: Context) = p(c).getBoolean("date", true)
    fun setDate(c: Context, v: Boolean) = p(c).edit().putBoolean("date", v).apply()

    fun dock(c: Context) = p(c).getBoolean("dock", true)
    fun setDock(c: Context, v: Boolean) = p(c).edit().putBoolean("dock", v).apply()

    fun search(c: Context) = p(c).getBoolean("search", true)
    fun setSearch(c: Context, v: Boolean) = p(c).edit().putBoolean("search", v).apply()

    fun glassTint(c: Context) = p(c).getInt("glass_tint", 0)
    fun setGlassTint(c: Context, v: Int) = p(c).edit().putInt("glass_tint", v.coerceIn(0, 3)).apply()

    fun iconStyle(c: Context) = p(c).getInt("icon_style", 0)
    fun setIconStyle(c: Context, v: Int) = p(c).edit().putInt("icon_style", v.coerceIn(0, 2)).apply()
}
