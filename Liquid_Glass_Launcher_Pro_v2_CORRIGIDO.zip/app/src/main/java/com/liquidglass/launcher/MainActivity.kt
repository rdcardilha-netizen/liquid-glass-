package com.liquidglass.launcher

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private data class AppEntry(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)
    private val apps = mutableListOf<AppEntry>()
    private lateinit var root: LinearLayout
    private lateinit var grid: GridLayout
    private lateinit var count: TextView
    private lateinit var searchInput: EditText

    private val white = Color.WHITE
    private val textColor = Color.WHITE
    private val glassFill: Int
        get() {
            val alpha = (Prefs.transparency(this) * 255 / 100).coerceIn(0, 255)
            val rgb = when (Prefs.glassTint(this)) {
                1 -> 0xFF101827.toInt()
                2 -> 0xFFEAF2FF.toInt()
                3 -> 0xFF111111.toInt()
                else -> 0xFFFFFFFF.toInt()
            }
            val finalAlpha = if (Prefs.glassTint(this) == 2) (alpha * 0.68f).toInt() else alpha
            return Color.argb(finalAlpha, Color.red(rgb), Color.green(rgb), Color.blue(rgb))
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
        window.setBackgroundDrawableResource(android.R.color.transparent)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        loadApps()
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) render()
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { info: ResolveInfo ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == packageName) null else AppEntry(info.loadLabel(packageManager).toString(), pkg, info.loadIcon(packageManager))
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
            .forEach { apps.add(it) }
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(36), dp(18), dp(12))
            setBackgroundColor(Color.TRANSPARENT)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(4), dp(5), dp(18))
        }
        if (Prefs.clock(this)) {
            top.addView(TextView(this).apply {
                text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                textSize = 58f
                letterSpacing = -0.045f
                typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                setTextColor(white)
                setShadowLayer(12f, 0f, 2f, 0x66000000)
            })
        }
        if (Prefs.date(this)) {
            top.addView(TextView(this).apply {
                text = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("pt", "BR")).format(Date())
                textSize = 14f
                setTextColor(0xFFF3F4F8.toInt())
                setShadowLayer(8f, 0f, 1f, 0x88000000.toInt())
            })
        }
        root.addView(top)

        if (Prefs.search(this)) {
            val searchPanel = glassPanel(26).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(15), 0, dp(15), 0)
            }
            searchPanel.addView(TextView(this).apply {
                text = "⌕"
                textSize = 27f
                setTextColor(white)
                setPadding(0, 0, dp(9), 0)
            })
            searchInput = EditText(this).apply {
                hint = "Pesquisar"
                setHintTextColor(0xFFDDE1EA.toInt())
                setTextColor(white)
                textSize = 15f
                setSingleLine(true)
                background = null
                imeOptions = EditorInfo.IME_ACTION_SEARCH
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { showApps(s?.toString() ?: "") }
                    override fun afterTextChanged(s: Editable?) {}
                })
            }
            searchPanel.addView(searchInput, LinearLayout.LayoutParams(0, dp(48), 1f))
            root.addView(searchPanel)
        }

        val heading = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), dp(20), dp(5), dp(10))
        }
        heading.addView(TextView(this).apply {
            text = "Sugestões"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            setShadowLayer(8f, 0f, 1f, 0x99000000.toInt())
        }, LinearLayout.LayoutParams(0, -2, 1f))
        count = TextView(this).apply {
            textSize = 11f
            setTextColor(0xFFE6E8EF.toInt())
        }
        heading.addView(count)
        root.addView(heading)

        val scroll = ScrollView(this).apply { clipToPadding = false }
        grid = GridLayout(this).apply {
            columnCount = Prefs.columns(this@MainActivity)
            setPadding(0, dp(2), 0, dp(12))
        }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        if (Prefs.dock(this)) {
            val dock = glassPanel(30).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(7), dp(8), dp(7))
            }
            apps.take(4).forEach { app ->
                dock.addView(createAppIcon(app, true), LinearLayout.LayoutParams(0, dp(66), 1f))
            }
            root.addView(dock)
        }

        val settings = TextView(this).apply {
            text = "⚙  Personalizar"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(white)
            setPadding(0, dp(10), 0, dp(3))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        root.addView(settings)
        setContentView(root)
        showApps("")
    }

    private fun showApps(query: String) {
        if (!::grid.isInitialized) return
        grid.removeAllViews()
        val results = apps.filter { it.label.contains(query.trim(), true) }
        count.text = "${results.size} apps"
        results.forEach { app ->
            val item = createAppIcon(app, false)
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(if (Prefs.labels(this@MainActivity)) 102 else 82)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(2), dp(3), dp(2), dp(5))
            }
            grid.addView(item, lp)
        }
        if (results.isEmpty()) {
            grid.addView(TextView(this).apply {
                text = "Nenhum aplicativo encontrado"
                setTextColor(white)
                gravity = Gravity.CENTER
            }, GridLayout.LayoutParams().apply { columnSpec = GridLayout.spec(0, Prefs.columns(this@MainActivity)) })
        }
    }

    private fun createAppIcon(app: AppEntry, compact: Boolean): View {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(3), dp(2), dp(3))
            setOnClickListener {
                packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }
            }
        }
        val iconSize = if (compact) 48 else Prefs.iconSize(this)
        val holder = FrameLayout(this).apply {
            background = rounded(glassFill, 18, 0x99FFFFFF.toInt())
            foreground = rounded(0x18FFFFFF, 18, 0x44FFFFFF)
            addView(ImageView(this@MainActivity).apply {
                setImageDrawable(app.icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(5), dp(5), dp(5), dp(5))
            }, FrameLayout.LayoutParams(dp(iconSize), dp(iconSize), Gravity.CENTER))
        }
        item.addView(holder, LinearLayout.LayoutParams(dp(iconSize + 8), dp(iconSize + 8)))
        if (!compact && Prefs.labels(this)) {
            item.addView(TextView(this).apply {
                text = app.label
                textSize = 11f
                maxLines = 1
                gravity = Gravity.CENTER
                setTextColor(white)
                setShadowLayer(6f, 0f, 1f, 0xAA000000.toInt())
                setPadding(0, dp(5), 0, 0)
                ellipsize = android.text.TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(-1, -2))
        }
        return item
    }

    private fun glassPanel(radius: Int): LinearLayout = LinearLayout(this).apply {
        background = rounded(glassFill, radius, 0x77FFFFFF)
        if (Build.VERSION.SDK_INT >= 31 && Prefs.blur(this@MainActivity)) {
            // Background remains translucent on all Android versions; native blur is a best-effort visual enhancement.
            try {
                setRenderEffect(android.graphics.RenderEffect.createBlurEffect(12f, 12f, android.graphics.Shader.TileMode.CLAMP))
            } catch (_: Exception) {}
        }
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
